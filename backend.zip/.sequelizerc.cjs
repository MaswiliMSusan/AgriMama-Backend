const path = require("path");

module.exports = {
  config: path.resolve("config", "config.cjs"),
  "models-path": path.resolve("src", "models"),
  "migrations-path": path.resolve("migrations"),
  "seeders-path": path.resolve("seeders"),
};